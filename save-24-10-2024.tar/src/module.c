#include "module.h"

int carre(int n) {
	return n*n;
}