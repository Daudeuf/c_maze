#include "module_sec.h"

int add(int n, int b) {
	return n+b;
}