#ifndef MODULE_H
#define MODULE_H

int carre(int n);

#endif