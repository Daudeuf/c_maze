#include "affichage.h"

void start(int height, int width, int** grid);