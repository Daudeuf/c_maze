int menu(void);
void afficher_lab(int** grid, int height, int width);