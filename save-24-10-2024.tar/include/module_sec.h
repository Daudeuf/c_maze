#ifndef MODULE_SEC_H
#define MODULE_SEC_H

int add(int n, int b);

#endif